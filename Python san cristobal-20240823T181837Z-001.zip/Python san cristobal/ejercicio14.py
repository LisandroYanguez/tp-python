num_filas = int(input("Introduce el número de filas para la pirámide inversa: "))
for i in range(num_filas, 0, -1):
    print('*' * i)
