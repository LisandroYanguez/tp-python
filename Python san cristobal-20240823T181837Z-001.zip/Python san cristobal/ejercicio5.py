num1=int(input("Ingrese el primer numero: "))
num2=int(input("ingrese el segundo numero: "))
num3=int(input("Ingrese el tercer numero: "))
menor=min(num1,num2,num3)
print(f"El menor de los numeros es : ",menor)

