num1=int(input("ingrese un numero"))
if num1 % 2 == 0:
    print(f"El numero es par")
else:
    print(f"El numero es impar")
