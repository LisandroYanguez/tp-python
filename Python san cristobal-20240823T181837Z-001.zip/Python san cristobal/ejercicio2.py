resultado = 10 - 4
print("La diferencia entre 10 y 4 es:", resultado)
