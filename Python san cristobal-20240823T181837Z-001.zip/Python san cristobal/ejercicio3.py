
edad = int(input("Por favor, ingresa tu edad: "))
print(f"Tienes {edad} años.")


