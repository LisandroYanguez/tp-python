num1=int(input("Ingrese el primer numero: "))
num2=int(input("ingrese el segundo numero: "))
producto=num1*num2
print(f"El producto de los numeros es :",producto)