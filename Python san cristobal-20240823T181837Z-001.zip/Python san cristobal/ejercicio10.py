numero = int(input("Ingresa un número: "))
print(f"Múltiplos de 3 menores a {numero}:")
for i in range(3, numero, 3):
    print(i)
