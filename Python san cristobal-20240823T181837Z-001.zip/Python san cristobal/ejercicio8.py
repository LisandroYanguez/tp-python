num = int(input("Ingrese un numero : "))
if num % 4 == 0 :
    print(f"El numero es divisible por 4")
else:
    print(f"El numero no es divisible por 4")
if num % 6 == 0 :
    print(f"El numero es divisible por 6")
else:
    print(f"El numero no es divisible por 6")
if num % 8 == 0 :
    print(f"El numero es divisible por 8")
else:
    print(f"El numero no es divisible por 8")
if num % 10 == 0 :
    print(f"El numero es divisible por 10")
else:
    print(f"El numero no es divisible por 10")