num_filas = int(input("Introduce el número de filas para la pirámide: "))
for i in range(1, num_filas + 1):
    print('*' * i)
